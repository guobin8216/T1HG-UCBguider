#/home/guobin/miniconda3/envs/T1HG_model/bin/python
#python version: 3.7.4

def listLOO(PAT):
    import pickle
    if PAT==0:
        fam = pickle.load(open('inputs/featnames.p', 'rb'))
    else:
        raise Exception('Only PAT agnostic allowed')

    all_feats = fam['clin']+fam['dna']+fam['rna']+fam['digpath']+fam['chemo']
    fam_name = ['LOO_{}'.format(x) for x in all_feats]
    return fam_name

def getLOO(PAT, name):
    import pickle
    if PAT==0:
        fam = pickle.load(open('inputs/featnames.p', 'rb'))
    else:
        raise Exception('Only PAT agnostic allowed')

    all_feats = fam['clin']+fam['dna']+fam['rna']+fam['digpath']+fam['chemo']

    feat = name.split('_')[1]
    if feat=='median':
        feat='median_lymph_KDE_knn_50'
    loo_feats = [x for x in all_feats if x!=feat]

    return loo_feats
