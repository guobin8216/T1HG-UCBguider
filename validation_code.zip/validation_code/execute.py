import os
import run_models

PAT = -1

rseeds = [1,2,3,4,5]
featlist = ['clin', 'cnv.bin', 'gene.cnv', 'promoter.amf', 'mhb.mhl', 'gene.tpm', 'dna', 'rna', 'clin_dna', 'clin_rna', 'clin_dna_rna']
PAT_str = {1:'pos', -1:'nes'}

for rs in rseeds:
    output_name = 'results_PAT{}_rs{}'.format(PAT_str[PAT], rs)
    os.makedirs(output_name)
    for feats in featlist:
        run_models.main(feats, PAT, rs)
        os.system('mv *csv *pdf {}'.format(output_name))
    os.system('mv *txt {}'.format(output_name))
