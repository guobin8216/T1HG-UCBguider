#/home/guobin/miniconda3/envs/T1HG_model/bin/python
#python version: 3.7.4

def defineFeatures(whichFeat, PAT=0):
    import pickle
    fam = pickle.load(open('../inputs/featnames.p', 'rb'))
    
    if whichFeat == 'clin':
        feats = fam['clin']
    elif whichFeat == 'cnv.bin':
        feats = fam['cnv.bin']
    elif whichFeat == 'gene.cnv':
        feats = fam['gene.cnv']
    elif whichFeat == 'promoter.amf':
        feats = fam['promoter.amf']
    elif whichFeat == 'mhb.mhl':
        feats = fam['mhb.mhl']
    elif whichFeat == 'gene.tpm':
        feats = fam['gene.tpm']
    elif whichFeat == 'dna':
        feats = fam['cnv.bin']+fam['gene.cnv']+fam['promoter.amf']+fam['mhb.mhl']
    elif whichFeat == 'rna':
        feats = fam['gene.tpm']
    elif whichFeat == 'clin_dna':
        feats = fam['clin']+fam['cnv.bin']+fam['gene.cnv']+fam['promoter.amf']+fam['mhb.mhl']
    elif whichFeat == 'clin_rna':
        feats = fam['clin']+fam['gene.tpm']
    elif whichFeat == 'clin_dna_rna':
        feats = fam['clin']+fam['cnv.bin']+fam['gene.cnv']+fam['promoter.amf']+fam['mhb.mhl']+fam['gene.tpm']
    return feats

def writeResponse(yreal, yid, prefix):
    f = open('predictions.txt', 'a')

    f.write(prefix+'resp ')
    for eachy in yreal:
        f.write('{} '.format(eachy))
    f.write('\n')

    f.write(prefix+'ID ')
    for eachy in yid:
        f.write('{} '.format(eachy))
    f.write('\n')

    f.close()

def defineTestSet(df_test, feats, PAT=0, returnTrialID=False):
    if PAT!=0:
        df_test = df_test[df_test['PAT.status']==PAT].copy()
        #feats = [x for x in feats if x not in ['PAT.status','ERPAT.status']]
    df_test_reshuffled = df_test.copy().sample(frac=1, random_state=0).reset_index(drop=True)
    X = df_test_reshuffled[feats].copy()
    if returnTrialID==True:
        return X, df_test_reshuffled['Trial.ID'].copy()
    return X

def defineResponse(df,criterion,PAT=0):
    if PAT!=0:
        df = df[df['PAT.status']==PAT].copy()
    df_reshuffled = df.copy().sample(frac=1, random_state=0).reset_index(drop=True)
    y = df_reshuffled['resp.'+criterion].copy()
    return y

def plotStyle():
    from matplotlib import rcParams
    rcParams['font.family'] = 'sans-serif'
    rcParams['font.sans-serif'] = ['.Helvetica Neue DeskInterface']
    rcParams['font.size'] = 18
    rcParams['axes.linewidth'] = 2
    rcParams['grid.linewidth'] = 2
    rcParams['grid.color'] = 'gainsboro'
    rcParams['font.weight'] = 'normal'
    rcParams['axes.labelweight'] = 'bold'
    rcParams['axes.labelsize'] = 21
    rcParams['legend.edgecolor'] = 'none'
    rcParams["axes.spines.right"] = False
    rcParams["axes.spines.top"] = False

def removeBev(df):
    new_df = df[df['Chemo.Bev']!=True].reset_index(drop=True).copy()
    return new_df

def artemisOnly(df):
    new_df = df[df['Trial.ID'].str.contains('A')].reset_index(drop=True).copy()
    return new_df

def PBCPOnly(df):
    new_df = df[df['Trial.ID'].str.contains('T')].reset_index(drop=True).copy()
    return new_df


def main(whichFeats, PAT_str, random_seed):
## SETUP
    from classification_models import  final_test, test_all_models
    import pandas as pd
    import numpy as np
    import pickle
    plotStyle()

    print('Running {} models, with PAT={} and RS={}'.format(whichFeats, PAT_str, random_seed))

## INPUT
    PAT = int(PAT_str)
    if PAT==-1:
        df_test_Progression = pd.read_csv('../inputs/testing_PATneg_df.csv')
    elif PAT==1:
        df_test_Progression = pd.read_csv('../inputs/testing_PATpos_df.csv')


    ### Only Artemis / PBCP
    #df_test_Progression = PBCPOnly(df_test_Progression)

## DATASET
    feats = defineFeatures(whichFeats, PAT=PAT)
    Xtest_Progression, trialID_Progression = defineTestSet(df_test_Progression, feats, returnTrialID=True)

    ## Limited dataset
    parent_folder = '../trained_models/results'

## MODELS
    ### Progression
    for rcut in [1.0,0.9,0.8,0.7]:
        Progression_refits = pickle.load(open('{}_{}_0_{}_{}/{}_Progression_refits.pkl'.format(parent_folder, whichFeats, rcut, random_seed, whichFeats), 'rb'))
        ytest_Progression = defineResponse(df_test_Progression, 'Progression')
        writeResponse(ytest_Progression, trialID_Progression, 'Progression ')
        test_all_models(Xtest_Progression, ytest_Progression, Progression_refits, 'Progression_{}_r{}'.format(whichFeats, rcut))

if __name__ == "__main__":
    import sys
    main(sys.argv[1], sys.argv[2], sys.argv[3])
